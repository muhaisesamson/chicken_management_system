const DB_NAME = "ChickFarmDB";
const DB_VERSION = "1.0";
const DB_DESC = "ChickFarm local SQLite storage";
const DB_SIZE = 5 * 1024 * 1024;
let db = null;

const getDatabase = () => {
  if (db) return db;
  if (window.sqlitePlugin?.openDatabase) {
    db = window.sqlitePlugin.openDatabase({ name: DB_NAME, location: "default" });
    return db;
  }
  if (window.openDatabase) {
    db = window.openDatabase(DB_NAME, DB_VERSION, DB_DESC, DB_SIZE);
    return db;
  }
  throw new Error("SQLite is not available in this environment.");
};

const executeSql = (sql, params = []) => new Promise((resolve, reject) => {
  const database = getDatabase();
  database.transaction(tx => {
    tx.executeSql(sql, params,
      (_tx, result) => resolve(result),
      (_tx, error) => {
        reject(error);
        return false;
      }
    );
  }, reject);
});

const init = async () => {
  await executeSql(`
    CREATE TABLE IF NOT EXISTS records (
      id TEXT PRIMARY KEY,
      date TEXT,
      avgWeight TEXT,
      foodSupplied TEXT,
      deaths TEXT,
      injured TEXT,
      soldBirds TEXT,
      unsoldBirds TEXT,
      expenses TEXT,
      income TEXT,
      notes TEXT,
      addedBy TEXT,
      createdAt INTEGER,
      updatedAt INTEGER,
      syncStatus TEXT
    )
  `);
};

const normalizeTrendRows = (result, valueKey) => {
  const rows = [];
  for (let i = 0; i < result.rows.length; i += 1) {
    const item = result.rows.item(i);
    rows.push({
      date: item.date,
      value: Number(item[valueKey] || 0),
    });
  }
  return rows;
};

const getTotals = async () => {
  await init();
  const result = await executeSql(
    `SELECT
      COALESCE(SUM(CAST(deaths AS INTEGER)), 0) AS totalDeaths,
      COALESCE(SUM(CAST(foodSupplied AS REAL)), 0) AS totalFeed,
      COALESCE(SUM(CAST(expenses AS REAL)), 0) AS totalExpenses,
      COALESCE(SUM(CAST(income AS REAL)), 0) AS totalIncome
    FROM records
    WHERE syncStatus IS NULL OR syncStatus != 'deleted'`
  );
  const row = result.rows.item(0);
  return {
    totalDeaths: Number(row.totalDeaths || 0),
    totalFeed: Number(row.totalFeed || 0),
    totalExpenses: Number(row.totalExpenses || 0),
    totalIncome: Number(row.totalIncome || 0),
  };
};

const getFeedTrend = async () => {
  await init();
  const result = await executeSql(
    `SELECT date,
      COALESCE(SUM(CAST(foodSupplied AS REAL)), 0) AS feed
    FROM records
    WHERE syncStatus IS NULL OR syncStatus != 'deleted'
    GROUP BY date
    ORDER BY date ASC`
  );
  return normalizeTrendRows(result, "feed");
};

const getDeathTrend = async () => {
  await init();
  const result = await executeSql(
    `SELECT date,
      COALESCE(SUM(CAST(deaths AS INTEGER)), 0) AS deaths
    FROM records
    WHERE syncStatus IS NULL OR syncStatus != 'deleted'
    GROUP BY date
    ORDER BY date ASC`
  );
  return normalizeTrendRows(result, "deaths");
};

const getIncomeTrend = async () => {
  await init();
  const result = await executeSql(
    `SELECT date,
      COALESCE(SUM(CAST(income AS REAL)), 0) AS income
    FROM records
    WHERE syncStatus IS NULL OR syncStatus != 'deleted'
    GROUP BY date
    ORDER BY date ASC`
  );
  return normalizeTrendRows(result, "income");
};

const getExpensesTrend = async () => {
  await init();
  const result = await executeSql(
    `SELECT date,
      COALESCE(SUM(CAST(expenses AS REAL)), 0) AS expenses
    FROM records
    WHERE syncStatus IS NULL OR syncStatus != 'deleted'
    GROUP BY date
    ORDER BY date ASC`
  );
  return normalizeTrendRows(result, "expenses");
};

const getFeedVsDeaths = async () => {
  await init();
  const result = await executeSql(
    `SELECT date,
      COALESCE(SUM(CAST(foodSupplied AS REAL)), 0) AS feed,
      COALESCE(SUM(CAST(deaths AS INTEGER)), 0) AS deaths
    FROM records
    WHERE syncStatus IS NULL OR syncStatus != 'deleted'
    GROUP BY date
    ORDER BY date ASC`
  );
  const rows = [];
  for (let i = 0; i < result.rows.length; i += 1) {
    const item = result.rows.item(i);
    rows.push({
      date: item.date,
      feed: Number(item.feed || 0),
      deaths: Number(item.deaths || 0),
    });
  }
  return rows;
};

export default {
  getTotals,
  getFeedTrend,
  getDeathTrend,
  getIncomeTrend,
  getExpensesTrend,
  getFeedVsDeaths,
};
