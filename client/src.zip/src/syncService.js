import { initializeApp } from "firebase/app";
import {
  getFirestore,
  collection,
  doc,
  getDocs,
  setDoc,
  writeBatch,
  query,
  where,
  orderBy,
} from "firebase/firestore";
import dbService from "./dbService";

const FARM_ID = "defaultFarm";
const CHUNK_SIZE = 500;

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID",
};

const app = initializeApp(firebaseConfig);
const firestore = getFirestore(app);

const getCollectionRef = (farmId) => collection(
  firestore,
  "farms",
  farmId,
  "farmRecords"
);

const collectionRef = getCollectionRef(FARM_ID);

let syncLock = null;

const chunkArray = (array, size) => {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
};

const pushLocalBatch = async (records) => {
  const chunks = chunkArray(records, CHUNK_SIZE);
  for (const chunk of chunks) {
    const batch = writeBatch(firestore);
    chunk.forEach((record) => {
      const docRef = doc(getCollectionRef(FARM_ID), record.id);
      if (record.syncStatus === "deleted") {
        batch.delete(docRef);
      } else {
        batch.set(docRef, { ...record, syncStatus: "synced" }, { merge: true });
      }
    });
    await batch.commit();
  }
};

const pullRemoteRecords = async (lastSyncedAt) => {
  if (lastSyncedAt > 0) {
    const remoteQuery = query(
      collectionRef,
      where("updatedAt", ">", lastSyncedAt),
      orderBy("updatedAt", "asc")
    );
    const snapshot = await getDocs(remoteQuery);
    return snapshot.docs.map((docItem) => ({ id: docItem.id, ...docItem.data() }));
  }
  const snapshot = await getDocs(collectionRef);
  return snapshot.docs.map((docItem) => ({ id: docItem.id, ...docItem.data() }));
};

const sync = async () => {
  if (syncLock) {
    return syncLock;
  }

  syncLock = (async () => {
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      return dbService.getAllRecords();
    }

    const lastSyncedAt = await dbService.getLastSyncedAt();
    const pendingLocal = await dbService.getPendingChanges();

    if (pendingLocal.length > 0) {
      await pushLocalBatch(pendingLocal);
      const tombstoneIds = pendingLocal
        .filter((record) => record.syncStatus === "deleted")
        .map((record) => record.id);
      await Promise.all(tombstoneIds.map((id) => dbService.deleteRecord(id)));
    }

    const remoteRecords = await pullRemoteRecords(lastSyncedAt);
    const pendingById = Object.fromEntries(pendingLocal.map((record) => [record.id, record]));
    const localUpdates = [];

    for (const remote of remoteRecords) {
      const local = pendingById[remote.id];
      const localUpdated = Number(local?.updatedAt || 0);
      const remoteUpdated = Number(remote.updatedAt || 0);

      if (!local) {
        localUpdates.push({ ...remote, syncStatus: "synced" });
        continue;
      }

      if (remoteUpdated > localUpdated) {
        localUpdates.push({ ...remote, syncStatus: "synced" });
      } else if (localUpdated > remoteUpdated) {
        await pushLocalBatch([{ ...local, syncStatus: "synced" }]);
        localUpdates.push({ ...local, syncStatus: "synced" });
      }
    }

    if (localUpdates.length > 0) {
      await dbService.upsertRecords(localUpdates);
    }

    const maxRemoteUpdatedAt = remoteRecords.length
      ? Math.max(...remoteRecords.map((record) => Number(record.updatedAt || 0)))
      : lastSyncedAt;

    await dbService.setLastSyncedAt(maxRemoteUpdatedAt);
    return dbService.getAllRecords();
  })();

  syncLock.finally(() => {
    syncLock = null;
  });

  return syncLock;
};

export default {
  sync,
};
