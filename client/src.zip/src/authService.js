import dbService from "./dbService";
import userService from "./userService";

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2);

const createLocalEmail = (name) => {
  const cleaned = String(name || "").trim().toLowerCase().replace(/\s+/g, ".");
  return cleaned ? `${cleaned}@local` : "unknown@local";
};

const persistSession = async (user, organization) => {
  localStorage.setItem("cf_user", user.name);
  localStorage.setItem("cf_user_id", user.id);
  localStorage.setItem("cf_org_id", organization.id);
  await dbService.setCurrentUserId(user.id);
  await dbService.setCurrentOrgId(organization.id);
};

const createSession = async (name) => {
  const userId = `user_${uid()}`;
  const organizationId = `org_${uid()}`;
  const user = {
    id: userId,
    name,
    email: createLocalEmail(name),
    role: "owner",
    organizationId,
    createdAt: Date.now(),
  };
  const organization = {
    id: organizationId,
    name: `${name}'s Farm`,
    ownerId: userId,
    createdAt: Date.now(),
    members: [userId],
  };
  await userService.createOrganization(organization);
  await userService.createUser(user);
  await persistSession(user, organization);
  return { user, organization };
};

const loginOrSignup = async (name) => {
  const trimmed = String(name || "").trim();
  if (!trimmed) {
    throw new Error("Please provide a valid user name.");
  }

  await dbService.init();
  let user = await userService.getUserByName(trimmed);
  if (user) {
    const organization = await userService.getOrganizationById(user.organizationId);
    const normalizedUser = userService.normalizeUserRole(user, organization);
    await persistSession(normalizedUser, organization);
    return { user: normalizedUser, organization };
  }

  return createSession(trimmed);
};

const restoreSession = async () => {
  await dbService.init();
  const storedUserId = localStorage.getItem("cf_user_id");
  const storedName = localStorage.getItem("cf_user");

  let user = null;
  if (storedUserId) {
    user = await userService.getUserById(storedUserId);
  }

  if (!user && storedName) {
    user = await userService.getUserByName(storedName);
  }

  if (!user) {
    return null;
  }

  const organization = user.organizationId
    ? await userService.getOrganizationById(user.organizationId)
    : null;
  const normalizedUser = userService.normalizeUserRole(user, organization);

  if (organization) {
    await persistSession(normalizedUser, organization);
  }

  return {
    user: normalizedUser,
    organization,
  };
};

export default {
  loginOrSignup,
  restoreSession,
};
