const DB_NAME = "ChickFarmDB";
const DB_VERSION = "1.0";
const DB_DESC = "ChickFarm local SQLite storage";
const DB_SIZE = 5 * 1024 * 1024;
let db = null;

const getDatabase = () => {
  if (db) return db;

  if (window.sqlitePlugin?.openDatabase) {
    db = window.sqlitePlugin.openDatabase({ name: DB_NAME, location: "default" });
    return db;
  }

  if (window.openDatabase) {
    db = window.openDatabase(DB_NAME, DB_VERSION, DB_DESC, DB_SIZE);
    return db;
  }

  throw new Error("SQLite is not available in this environment.");
};

const executeSql = (sql, params = []) => new Promise((resolve, reject) => {
  const database = getDatabase();
  database.transaction(tx => {
    tx.executeSql(sql, params,
      (_tx, result) => resolve(result),
      (_tx, error) => {
        reject(error);
        return false;
      }
    );
  }, reject);
});

const columnExists = async (table, column) => {
  const result = await executeSql(`PRAGMA table_info(${table})`);
  for (let i = 0; i < result.rows.length; i += 1) {
    if (result.rows.item(i).name === column) {
      return true;
    }
  }
  return false;
};

const ensureColumn = async (table, column, definition) => {
  const exists = await columnExists(table, column);
  if (!exists) {
    await executeSql(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
};

const prepareRecord = (record, existing, defaultSyncStatus = "pending") => {
  const now = Date.now();
  return {
    id: record.id,
    date: record.date || "",
    avgWeight: record.avgWeight ?? "",
    foodSupplied: record.foodSupplied ?? "",
    deaths: record.deaths ?? "",
    injured: record.injured ?? "",
    soldBirds: record.soldBirds ?? "",
    unsoldBirds: record.unsoldBirds ?? "",
    expenses: record.expenses ?? "",
    income: record.income ?? "",
    notes: record.notes ?? "",
    addedBy: record.addedBy ?? "",
    organizationId: record.organizationId ?? existing?.organizationId ?? null,
    createdAt: record.createdAt || existing?.createdAt || now,
    updatedAt: record.updatedAt || now,
    syncStatus: record.syncStatus || existing?.syncStatus || defaultSyncStatus,
  };
};

const init = async () => {
  await executeSql(`
    CREATE TABLE IF NOT EXISTS records (
      id TEXT PRIMARY KEY,
      date TEXT,
      avgWeight TEXT,
      foodSupplied TEXT,
      deaths TEXT,
      injured TEXT,
      soldBirds TEXT,
      unsoldBirds TEXT,
      expenses TEXT,
      income TEXT,
      notes TEXT,
      addedBy TEXT,
      organizationId TEXT,
      createdAt INTEGER,
      updatedAt INTEGER,
      syncStatus TEXT
    )
  `);
  await ensureColumn("records", "organizationId", "TEXT");
  await executeSql(`
    CREATE TABLE IF NOT EXISTS metadata (
      key TEXT PRIMARY KEY,
      value TEXT
    )
  `);
  await executeSql(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT,
      email TEXT,
      role TEXT,
      organizationId TEXT,
      createdAt INTEGER
    )
  `);
  await executeSql(`
    CREATE TABLE IF NOT EXISTS organizations (
      id TEXT PRIMARY KEY,
      name TEXT,
      ownerId TEXT,
      members TEXT,
      createdAt INTEGER
    )
  `);
};

const getMeta = async (key) => {
  await init();
  const result = await executeSql(
    "SELECT value FROM metadata WHERE key = ?",
    [key]
  );
  return result.rows.length ? result.rows.item(0).value : null;
};

const setMeta = async (key, value) => {
  await init();
  await executeSql(
    `INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)`,
    [key, String(value)]
  );
};

const getCurrentUserId = async () => {
  return await getMeta("currentUserId");
};

const setCurrentUserId = async (id) => {
  await setMeta("currentUserId", id);
};

const getCurrentOrgId = async () => {
  return await getMeta("currentOrgId");
};

const setCurrentOrgId = async (id) => {
  await setMeta("currentOrgId", id);
};

const parseOrganizationRow = (row) => ({
  id: row.id,
  name: row.name,
  ownerId: row.ownerId,
  createdAt: Number(row.createdAt || 0),
  members: JSON.parse(row.members || "[]"),
});

const getUserById = async (id) => {
  await init();
  const result = await executeSql("SELECT * FROM users WHERE id = ?", [id]);
  return result.rows.length ? result.rows.item(0) : null;
};

const getUserByName = async (name) => {
  await init();
  const result = await executeSql(
    "SELECT * FROM users WHERE LOWER(name) = LOWER(?) LIMIT 1",
    [name]
  );
  return result.rows.length ? result.rows.item(0) : null;
};

const saveUser = async (user) => {
  await init();
  await executeSql(
    `INSERT OR REPLACE INTO users (
      id, name, email, role, organizationId, createdAt
    ) VALUES (?, ?, ?, ?, ?, ?)`,
    [
      user.id,
      user.name,
      user.email,
      user.role,
      user.organizationId,
      user.createdAt || Date.now(),
    ]
  );
  return user;
};

const getOrganizationById = async (organizationId) => {
  await init();
  if (!organizationId) return null;
  const result = await executeSql("SELECT * FROM organizations WHERE id = ?", [organizationId]);
  return result.rows.length ? parseOrganizationRow(result.rows.item(0)) : null;
};

const saveOrganization = async (organization) => {
  await init();
  await executeSql(
    `INSERT OR REPLACE INTO organizations (
      id, name, ownerId, members, createdAt
    ) VALUES (?, ?, ?, ?, ?)`,
    [
      organization.id,
      organization.name,
      organization.ownerId,
      JSON.stringify(organization.members || []),
      organization.createdAt || Date.now(),
    ]
  );
  return getOrganizationById(organization.id);
};

const getOrganizationMembers = async (organizationId) => {
  await init();
  const result = await executeSql(
    "SELECT * FROM users WHERE organizationId = ?",
    [organizationId]
  );
  const rows = [];
  for (let i = 0; i < result.rows.length; i += 1) {
    rows.push(result.rows.item(i));
  }
  return rows;
};

const migrateRecordsToOrganization = async (organizationId) => {
  if (!organizationId) return;
  await init();
  await executeSql(
    "UPDATE records SET organizationId = ? WHERE organizationId IS NULL OR organizationId = ''",
    [organizationId]
  );
};

const getAllRecords = async () => {
  await init();
  const orgId = await getCurrentOrgId();
  if (!orgId) return [];
  const result = await executeSql(
    "SELECT * FROM records WHERE (syncStatus IS NULL OR syncStatus != 'deleted') AND organizationId = ? ORDER BY date DESC, createdAt DESC",
    [orgId]
  );
  const rows = [];
  for (let i = 0; i < result.rows.length; i += 1) {
    rows.push(result.rows.item(i));
  }
  return rows;
};

const getPendingChanges = async () => {
  await init();
  const orgId = await getCurrentOrgId();
  if (!orgId) return [];
  const result = await executeSql(
    "SELECT * FROM records WHERE (syncStatus IS NULL OR syncStatus IN ('pending', 'deleted')) AND organizationId = ?",
    [orgId]
  );
  const rows = [];
  for (let i = 0; i < result.rows.length; i += 1) {
    rows.push(result.rows.item(i));
  }
  return rows;
};

const saveAllRecords = async (records) => {
  await init();
  const orgId = await getCurrentOrgId();

  const existingResult = await executeSql(
    "SELECT * FROM records WHERE (syncStatus IS NULL OR syncStatus != 'deleted') AND organizationId = ?",
    [orgId]
  );
  const existingById = {};
  const existingIds = [];
  for (let i = 0; i < existingResult.rows.length; i += 1) {
    const row = existingResult.rows.item(i);
    existingById[row.id] = row;
    existingIds.push(row.id);
  }

  const normalizedRecords = records.map((record) => ({
    ...record,
    organizationId: record.organizationId || orgId,
  }));
  const newIds = normalizedRecords.map((record) => record.id);
  const deletedIds = existingIds.filter((id) => !newIds.includes(id));

  return new Promise((resolve, reject) => {
    const database = getDatabase();
    database.transaction(tx => {
      normalizedRecords.forEach((record) => {
        const existing = existingById[record.id];
        const normalized = prepareRecord(record, existing, "pending");
        tx.executeSql(
          `INSERT OR REPLACE INTO records (
            id, date, avgWeight, foodSupplied, deaths, injured,
            soldBirds, unsoldBirds, expenses, income, notes,
            addedBy, organizationId, createdAt, updatedAt, syncStatus
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            normalized.id,
            normalized.date,
            normalized.avgWeight,
            normalized.foodSupplied,
            normalized.deaths,
            normalized.injured,
            normalized.soldBirds,
            normalized.unsoldBirds,
            normalized.expenses,
            normalized.income,
            normalized.notes,
            normalized.addedBy,
            normalized.organizationId,
            normalized.createdAt,
            normalized.updatedAt,
            normalized.syncStatus,
          ]
        );
      });

      deletedIds.forEach((id) => {
        const existing = existingById[id] || {};
        const tombstone = prepareRecord({ id }, existing, "deleted");
        tombstone.organizationId = existing.organizationId || orgId;
        tombstone.syncStatus = "deleted";
        tombstone.updatedAt = Date.now();
        tx.executeSql(
          `INSERT OR REPLACE INTO records (
            id, date, avgWeight, foodSupplied, deaths, injured,
            soldBirds, unsoldBirds, expenses, income, notes,
            addedBy, organizationId, createdAt, updatedAt, syncStatus
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            tombstone.id,
            tombstone.date,
            tombstone.avgWeight,
            tombstone.foodSupplied,
            tombstone.deaths,
            tombstone.injured,
            tombstone.soldBirds,
            tombstone.unsoldBirds,
            tombstone.expenses,
            tombstone.income,
            tombstone.notes,
            tombstone.addedBy,
            tombstone.organizationId,
            tombstone.createdAt,
            tombstone.updatedAt,
            tombstone.syncStatus,
          ]
        );
      });
    }, reject, resolve);
  });
};

const upsertRecords = async (records) => {
  await init();
  const orgId = await getCurrentOrgId();
  return new Promise((resolve, reject) => {
    const database = getDatabase();
    database.transaction(tx => {
      records.forEach((record) => {
        const normalized = prepareRecord({ ...record, organizationId: record.organizationId || orgId }, null, "synced");
        normalized.syncStatus = record.syncStatus || "synced";
        tx.executeSql(
          `INSERT OR REPLACE INTO records (
            id, date, avgWeight, foodSupplied, deaths, injured,
            soldBirds, unsoldBirds, expenses, income, notes,
            addedBy, organizationId, createdAt, updatedAt, syncStatus
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            normalized.id,
            normalized.date,
            normalized.avgWeight,
            normalized.foodSupplied,
            normalized.deaths,
            normalized.injured,
            normalized.soldBirds,
            normalized.unsoldBirds,
            normalized.expenses,
            normalized.income,
            normalized.notes,
            normalized.addedBy,
            normalized.organizationId,
            normalized.createdAt,
            normalized.updatedAt,
            normalized.syncStatus,
          ]
        );
      });
    }, reject, resolve);
  });
};

const deleteRecord = async (id) => {
  await init();
  await executeSql("DELETE FROM records WHERE id = ?", [id]);
};

export default {
  init,
  getAllRecords,
  getPendingChanges,
  getUserById,
  getUserByName,
  saveUser,
  getOrganizationById,
  saveOrganization,
  getOrganizationMembers,
  getCurrentUserId,
  setCurrentUserId,
  getCurrentOrgId,
  setCurrentOrgId,
  migrateRecordsToOrganization,
  getLastSyncedAt: async () => {
    const value = await getMeta("lastSyncedAt");
    return value ? Number(value) : 0;
  },
  setLastSyncedAt: async (timestamp) => {
    await setMeta("lastSyncedAt", timestamp);
  },
  saveAllRecords,
  upsertRecords,
  deleteRecord,
};
